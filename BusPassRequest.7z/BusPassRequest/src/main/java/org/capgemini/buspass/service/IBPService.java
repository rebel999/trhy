package org.capgemini.buspass.service;

import java.sql.SQLException;

import org.capgemini.buspass.model.AdminLogin;

public interface IBPService {

	public boolean isValid(AdminLogin adminLogin) throws SQLException;

}
