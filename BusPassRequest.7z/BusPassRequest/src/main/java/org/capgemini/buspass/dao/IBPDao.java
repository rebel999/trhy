package org.capgemini.buspass.dao;

import java.sql.SQLException;

import org.capgemini.buspass.model.AdminLogin;

public interface IBPDao {

	public boolean isValid(AdminLogin adminLogin) throws SQLException;
}
