package org.capgemini.buspass.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.capgemini.buspass.model.AdminLogin;

public class BPDaoImpl implements IBPDao{

	public boolean isValid(AdminLogin adminLogin) throws SQLException {

		String sql="Select * from logintable where username=? and password=?";
		
		try(PreparedStatement preparedstatement=getMySQLDBConnection().prepareStatement(sql);){
			
				
				preparedstatement.setString(1, adminLogin.getUsername());
				preparedstatement.setString(2, adminLogin.getPassword());
				ResultSet rs=preparedstatement.executeQuery();
				if(rs.next()) {
					return true;
				}
			}
		
		return false;
		
	}

	private Connection getMySQLDBConnection() {
		Connection conn=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "India123");
			return conn;
		}catch (SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			
		}
		return null;
	}
	
	
}

