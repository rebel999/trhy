package org.capgemini.buspass.dao;

public interface Querys {

	public final static String addRoute="insert into ";
}
