package org.capgemini.buspass.service;

import java.sql.SQLException;

import org.capgemini.buspass.dao.BPDaoImpl;
import org.capgemini.buspass.dao.IBPDao;
import org.capgemini.buspass.model.AdminLogin;

public class BPServiceImpl implements IBPService {

	IBPDao dao=new BPDaoImpl();
	public boolean isValid(AdminLogin adminLogin) throws SQLException {
		if(dao.isValid(adminLogin)) {
			return true;
		}
		
		return false;
	}

}
