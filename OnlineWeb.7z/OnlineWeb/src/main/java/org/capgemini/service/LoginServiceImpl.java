package org.capgemini.service;

import org.capgemini.dao.ILoginDao;
import org.capgemini.dao.LoginDaoImpl;
import org.capgemini.model.LoginClass;

public class LoginServiceImpl implements ILoginService {
	ILoginDao ilogindao=new LoginDaoImpl();

	@Override
	public boolean isValid(LoginClass lc) {
		if(ilogindao.isValid(lc)) {
		return true;	
		}
		return false;
	}

}
