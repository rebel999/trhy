package org.capgemini;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.model.LoginClass;
import org.capgemini.service.ILoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginValid
 */
@WebServlet("/LoginValidServlet")
public class LoginValidServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginValidServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("pwd");
		LoginClass lc=new LoginClass(username,password);
		ILoginService iLoginService=(ILoginService) new LoginServiceImpl();

		if(iLoginService.isValid(lc)) {
			response.sendRedirect("htmlpages/page.html");
		}else {
			//PrintWriter pw=response.getWriter();
			//pw.println("Invalid");
			String message = "Invalid username and password";

			request.getRequestDispatcher("NewFile.html").include(request, response);
		}
	}

}
